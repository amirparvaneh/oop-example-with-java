public class Teacher extends Person{
    private int fixSalary;
    private int precedence;
    public Teacher(){
        System.out.println("the teacher with default constructor");
    }
    public Teacher(String name, String id, Gender gender) {
        super(name, id,gender);
    }

    public Teacher(String name, String id, Gender gender, int fixSalary, int precedence) {
        super(name, id, gender);
        this.fixSalary = fixSalary;
        this.precedence = precedence;
    }

    public int getPrecedence() {
        return precedence;
    }

    public void setPrecedence(int precedence) {
        this.precedence = precedence;
    }

    public int getFixSalary() {
        return fixSalary;
    }


    public void setFixSalary(int fixSalary) {
        this.fixSalary = fixSalary;
    }

    @Override
    public void computeSalary() {
        int salary = fixSalary+(100*precedence);
        System.out.println("this is the whole salary for teacher "+getName()+" with id of \""+getId()+"\"");
        System.out.println(salary+"$");
    }


}
