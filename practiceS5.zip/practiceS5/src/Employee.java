public class Employee extends Person {
    private int precedence;
    private int salary;

    public Employee(String name, String id, Gender gender, int salary,int precedence) {
        super(name, id, gender);
        this.precedence = precedence;
        this.salary = salary;
    }

    public Employee(){

    }

    public Employee(String name, String id,Gender gender) {
        super(name, id,gender);

    }

    @Override
    public void computeSalary(){
        int finalSalary = salary + (50*precedence);
        System.out.println("this is the salary for employee "+getName()+" with id of \""+getId()+"\"");
        System.out.println(finalSalary+"$");
    }
    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    public int getPrecedence() {
        return precedence;
    }

    public void setPrecedence(int precedence) {
        this.precedence = precedence;
    }
}
