public class Student extends Person{
    int salary = 300;

    public Student(String name, String id, Gender gender, Degree degree) {
        super(name, id, gender);
        this.degree = degree;
    }

    Degree degree ;

    public Student(String name, String id, int age,Gender gender) {
        super(name, id,gender);
    }

    @Override
    public void computeSalary() {
        int coefficient;
        switch (degree){
            case BS:
                coefficient = 3;
                break;
            case MS:
                coefficient = 5;
                break;
            case Phd:
                coefficient = 8;
                break;
            default:
                return;
        }
        int finalSalary = salary+(100*coefficient);
        System.out.println("this is a student salary for "+getName()+" with id of \""+getId()+"\"");
        System.out.println(finalSalary+"$");
    }

    public Student(Degree degree , Gender gender){

    }
}
