import java.lang.reflect.Type;

public abstract class Person {
    private String name;
    private String id ;
    private int age;


    public Person(){
        System.out.println("making person with default constructor");
    }

    public Person(String name, String id,Gender gender) {
        this.name = name;
        this.id = id;
        this.age = age;
    }
    //abstract method for Person class
    public abstract void computeSalary();



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
