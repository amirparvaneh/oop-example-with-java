import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Person a = new Employee("yasin", "444@P", Gender.FEMALE,13000,3);
        a.computeSalary();
        Teacher teacher = new Teacher("alireza","234@CE", Gender.MALE,23000,3);
        teacher.computeSalary();
        Person student = new Student("zahra","2482@P",Gender.FEMALE,Degree.Phd);
        student.computeSalary();
        Student student2 = new Student("sina","2323@PP",Gender.MALE,Degree.BS);
        student2.computeSalary();
        Course course = new Course("math","hard", 3);
        

    }
}
