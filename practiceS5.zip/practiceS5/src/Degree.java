public enum Degree {
    MS,
    BS,
    Phd

}
